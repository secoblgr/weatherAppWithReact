
<h1>React weather app with tailwindcss </h1>

<p>I used context for state management </p>

<p>You can visit here live preview https://sb-live-weather.netlify.app/ </p>
